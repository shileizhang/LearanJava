create trigger trigger1
  before INSERT
  on user
  for each row
begin
    if(NEW.name='zsl') then
        set NEW.name='zzzzz1';
    end if;
end;

